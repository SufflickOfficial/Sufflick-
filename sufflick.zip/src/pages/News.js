
import React from "react";

export function News() {
  return <div className="p-4">Top news stories of the day.</div>;
}
