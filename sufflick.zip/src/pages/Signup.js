
import React from "react";

export function Signup() {
  return <div className="p-4">Signup form goes here.</div>;
}
