
import React from "react";

export function Login() {
  return <div className="p-4">Login form goes here.</div>;
}
