
import React from "react";

export function Home() {
  return <div className="p-4">Welcome to Sufflick!</div>;
}
