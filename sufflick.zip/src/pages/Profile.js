
import React from "react";

export function Profile() {
  return <div className="p-4">User profile information and posts.</div>;
}
