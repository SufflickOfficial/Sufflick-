
import React from "react";

export function Navbar() {
  return (
    <nav className="bg-white shadow-md p-4 flex justify-between items-center">
      <span className="text-xl font-bold text-blue-600">Sufflick</span>
      <div className="space-x-4">
        <a href="/" className="text-gray-700 hover:text-blue-600">Home</a>
        <a href="/feed" className="text-gray-700 hover:text-blue-600">Feed</a>
        <a href="/news" className="text-gray-700 hover:text-blue-600">News</a>
        <a href="/profile" className="text-gray-700 hover:text-blue-600">Profile</a>
        <a href="/login" className="text-gray-700 hover:text-blue-600">Login</a>
      </div>
    </nav>
  );
}
